jQuery(function($){
     
    $('.showcase-site').wrapAll("<div class='showcase-wrapper autoForEach' />");

    var $showcase = $('.showcase-wrapper').isotope({
      // options
      itemSelector: '.showcase-site',
      layoutMode: 'fitRows'
    });
    
    $('#showcase-filter').change(function() {
        var filterValue = $(this).val();
        $showcase.isotope({ filter: filterValue });
    });
    
});