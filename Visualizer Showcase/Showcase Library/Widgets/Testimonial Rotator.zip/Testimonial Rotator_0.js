
var sliderScript = document.createElement('script');
sliderScript.src = '/portals/_default/Skins/TrueNorth/js/unslider-min.js';
document.getElementsByTagName('head')[0].appendChild(sliderScript);
jQuery(document).ready(function($) {  
    if (jQuery().unslider) {
    $('.testimonial-slider').unslider({
        autoplay: true,
        delay: 6500
    });
    
    }
});


