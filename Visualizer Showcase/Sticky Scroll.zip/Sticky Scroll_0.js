$(document).ready(function () {    
    
    function checkOffset() {
        
        if($('#social-float').offset().top + $('#social-float').height() >= $('#findMe').offset().top)
            $('#social-float').css('position', 'absolute');
        
        if($(document).scrollTop() + window.innerHeight < $('#findMe').offset().top)
            $('#social-float').css('position', 'fixed'); // restore when you scroll up
        }
    
    $(document).scroll(function() {
        checkOffset();
    });

});