


$(document).ready(function () {
    // Hover Play Video
    var figure = $(".right-sixty, .left-sixty");
    var vid = $("video");

    [].forEach.call(figure, function (item) {
        item.addEventListener('mouseover', hoverVideo, false);
        item.addEventListener('mouseout', hideVideo, false);
    });
    
    function hoverVideo(e) {  
        $(this).find('.tutorial-video')[0].play();
    }

    function hideVideo(e) {
        $(this).find('.tutorial-video')[0].pause(); 
    }
    
    //Remove Play Icon & Overlay On  Hover
    $(".right-sixty, .left-sixty").on("mouseenter", function() {
      $(this).find('.video-play-wrapper').stop().fadeOut("slow");
    });
    $(".right-sixty, .left-sixty").on("mouseleave", function() {
      $(this).find('.video-play-wrapper').stop().fadeIn("slow");
    });
    
});