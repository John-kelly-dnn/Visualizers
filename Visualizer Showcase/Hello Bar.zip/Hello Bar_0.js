$( document ).ready(function() {
    
    $('body').prepend($('#hello-bar'));
    
    // $('body').contents().prepend('<section id="hello-bar"></section>');
    
    
    
    
    var elementPosition = $('#hello-bar').offset();
    
    $(window).scroll(function(){
            if($(window).scrollTop() > elementPosition.top){
                $('#hello-bar').css({'position':'fixed','top':'0'});
                $('#Form').css({'margin-top':'45px'});
            } else {
                $('#hello-bar').css({'position':'static'});
                $('#Form').css({'margin-top':'0px'});
            }    
    });    
});